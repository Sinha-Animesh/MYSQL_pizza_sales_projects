
-- Determine the top 3 most ordered pizza types based on revenue for each pizza category.
-- WITH CTE (COMMON TABLE EXPRESSION)

 with A as (select pizza_types.category,pizza_types.name,
sum(order_details.quantity * pizzas.price) as revenue
from pizza_types join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details
on order_details.pizza_id = pizzas.pizza_id
group by pizza_types.category,pizza_types.name),

B as (select category, name, revenue,
rank() over(partition by category order by revenue desc) as rn
from A)

select * from B
where rn <=3