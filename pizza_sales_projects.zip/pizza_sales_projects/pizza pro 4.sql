-- Identify the most common pizza size ordered.

-- select quantity, count(order_details_id) from order_details
-- group by quantity;

-- select pizzas.size, count(order_details.order_details_id)
-- from pizzas
-- JOIN order_details AS common_pizza 
-- ON pizzas.pizza_id = order_details.pizza_id
-- GROUP BY pizzas.size;

-- Error Code: 1054. Unknown column 'order_details.order_details_id' in 'field list'

SELECT 
    pizzas.size,
    COUNT(common_pizza.order_details_id) AS order_count
FROM
    pizzas
        JOIN
    order_details AS common_pizza ON pizzas.pizza_id = common_pizza.pizza_id
GROUP BY pizzas.size
ORDER BY order_count DESC;
